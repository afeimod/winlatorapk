package com.example.datainsert.winlator.all;

import android.content.Context;
import android.content.pm.PackageManager;

import androidx.fragment.app.FragmentTransaction;

import com.winlator.MainActivity;
import com.winlator.R;
import com.winlator.core.TarZstdUtils;

import java.io.File;
import java.io.IOException;

/**
 * 内置/obb目录下/手动选择/ 处理数据包
 */
public class OBBFinder {
    private static final String TAG = "OBBFinder";
    static boolean shouldReturn = false; //标志extract是否应该停止睡眠并返回
    static boolean isExtractSuccess = false;//标志返回时 是true还是false

    //https://developer.android.google.cn/training/basics/intents/result?hl=zh-cn
//    public static void registerSelectOBBResult(MainActivity activity) {
//        dialog = new OBBSelectDialog(activity);
//        dialog.registerSelectOBBResult();
//    }

    /**
     * 把OBBImageInstaller中的TarZstdUtils改为OBBFinder且传入参数多一个activity。此时已经是在子线程内
     * 但是这样版本号存到txt里的就是-1了
     * 考虑：手动选择的话，返回activity会不会重新出发Installer？
     */
    public static boolean extract(File obbFile, File rootDir, MainActivity activity) {
        QH.refreshIsTest(activity);
        if (obbFile != null)
            return TarZstdUtils.extract(obbFile, rootDir);

        String assetFileName = findBundled(activity);
        if (assetFileName != null)
            return TarZstdUtils.extract(activity, assetFileName, rootDir);

        Thread currentThread = Thread.currentThread();
        shouldReturn = false;
        isExtractSuccess = false;
//        activity.runOnUiThread(() -> dialog.showDialog(currentThread));
        //服了旧androidx也没有dialogfragment.show   new OBBSelectFragment(currentThread).show(activity.getSupportFragmentManager(),"OBBSelectFragment")


        //R.id.FLFragmentContainer 用add不用replace，这样containerFragment还是isVisible，按返回键直接退出app而不是回到container
        activity.runOnUiThread(() -> {
            activity.preloaderDialog.closeOnUiThread();
            activity.getSupportFragmentManager().beginTransaction().add(QH.id.FLFragmentContainer, new OBBSelectFragment(currentThread),"OBBSelectFragment").commit();
        });

        while (!shouldReturn && !currentThread.isInterrupted()) {
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
                break;
            }
        }

        return isExtractSuccess;
    }


    private static String findBundled(MainActivity c) {
        try {
            String[] list = c.getAssets().list("obb");
            if (list == null || list.length == 0)
                return null;

            String subName = list[0];
//            if (subName.matches("main\\.[0-9]+\\..+\\.obb"))
//                version = Integer.parseInt(subName.split("\\.", 3)[1]);
//            else {
//                QH.refreshIsTest(c);
//                version = QH.versionCode;
//            }
            return "obb/" + subName;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }


    static String getIdealObbName(Context context) {
        int foundObbVersion;
        String packageName = context.getPackageName();
        try {
            foundObbVersion = context.getPackageManager().getPackageInfo(packageName, 0).versionCode;
        } catch (PackageManager.NameNotFoundException e) {
            foundObbVersion = 0;
        }
        return "main." + foundObbVersion + "." + packageName + ".obb";
    }

}
